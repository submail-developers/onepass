//
//  OclEnums.h
//  sdk
//
//  Created by 段晓杰 on 2023/2/23.
//  Copyright © 2023 段晓杰. All rights reserved.
//

#ifndef OclEnums_h
#define OclEnums_h

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSUInteger, PresentationDirection) {
    PresentationDirectionBottom = 0,  //底部  present默认效果
    PresentationDirectionRight,       //右边  导航栏效果
    PresentationDirectionTop,         //上面
    PresentationDirectionLeft,        //左边
};

typedef NS_ENUM(NSUInteger, LanguageType) {
    LanguageSimplifiedChinese = 0,  //简体中文
    LanguageTraditionalChinese,     //繁体中文
    LanguageEnglish,                //英文
};


#endif /* OclEnums_h */
