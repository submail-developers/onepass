//
//  AppDelegate.m
//  sdk
//
//  Created by 段晓杰 on 2020/7/23.
//  Copyright © 2020 段晓杰. All rights reserved.
//

#import "AppDelegate.h"
#import "ViewController.h"
#import "AuthorizationController.h"
#import "submail/OneViewController.h"
#import <submail_sdk/Submail.h>

#define APPID @"10015"
#define APPKEY @"730388900cc9624847b273d602262211"

@interface AppDelegate ()

@end

@implementation AppDelegate


@synthesize window = _window;
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    ViewController * vc = [[ViewController alloc] init];
    
    UINavigationController * nav = [[UINavigationController alloc] initWithRootViewController:vc];
    nav.navigationItem.backBarButtonItem.title = @"一键登录demo";
    self.window.rootViewController = nav;
    self.window.rootViewController.hidesBottomBarWhenPushed = YES;
    [self.window makeKeyAndVisible];
    
    //注册SDK
    [OclLogin.sharedInstance initWithAppId:APPID AppKey:APPKEY];
    
    //打印日志
    [OclLogin.sharedInstance printConsoleEnable:NO];
    
    //设置请求超时
    [OclLogin.sharedInstance setTimeoutInterval:3000];
    return YES;
}


#pragma mark - UISceneSession lifecycle


- (UISceneConfiguration *)application:(UIApplication *)application configurationForConnectingSceneSession:(UISceneSession *)connectingSceneSession options:(UISceneConnectionOptions *)options {
    // Called when a new scene session is being created.
    // Use this method to select a configuration to create the new scene with.
    return [[UISceneConfiguration alloc] initWithName:@"Default Configuration" sessionRole:connectingSceneSession.role];
}


- (void)application:(UIApplication *)application didDiscardSceneSessions:(NSSet<UISceneSession *> *)sceneSessions {
    // Called when the user discards a scene session.
    // If any sessions were discarded while the application was not running, this will be called shortly after application:didFinishLaunchingWithOptions.
    // Use this method to release any resources that were specific to the discarded scenes, as they will not return.
}


@end
