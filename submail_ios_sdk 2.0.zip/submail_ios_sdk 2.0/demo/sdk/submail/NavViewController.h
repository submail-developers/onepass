//
//  NavViewController.h
//  sdk
//
//  Created by 段晓杰 on 2021/6/21.
//  Copyright © 2021 段晓杰. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface NavViewController : UINavigationController

@end

NS_ASSUME_NONNULL_END
