//
//  TwoViewController.m
//  sdk
//
//  Created by 段晓杰 on 2021/6/9.
//  Copyright © 2021 段晓杰. All rights reserved.
//

#import "TwoViewController.h"
#import "ThreeViewController.h"

@interface TwoViewController ()

@end

@implementation TwoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.view.backgroundColor = [UIColor blueColor];
    
        float WIDTH = self.view.frame.size.width;
        int commBtnH = 44;
        int commBtnW = 240;
        UIButton * testButton = [UIButton buttonWithType:UIButtonTypeSystem];
        [testButton setFrame:CGRectMake((WIDTH-commBtnW)/2, 432, commBtnW, commBtnH)];
        [testButton setBackgroundColor:[UIColor blueColor]];
        [testButton setTitle:@"test" forState:UIControlStateNormal];
        [testButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [testButton addTarget:self action:@selector(openLogin) forControlEvents:UIControlEventTouchUpInside];
        [testButton.titleLabel setFont:[UIFont systemFontOfSize:16]];
        testButton.layer.cornerRadius = 4;
        [self.view addSubview:testButton];
}

- (void)openLogin{
    ThreeViewController * c = [[ThreeViewController alloc] init];
    [self.navigationController pushViewController:c animated:YES];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
