//
//  AuthorizationController.m
//  sdk
//
//  Created by 段晓杰 on 2020/7/23.
//  Copyright © 2020 段晓杰. All rights reserved.
//

#import "AuthorizationController.h"
#import <submail_sdk/OclLogin.h>
#import <CommonCrypto/CommonHMAC.h>
#import "MBProgressHUD.h"
#import "OneViewController.h"

#pragma mark =============AuthorizationController===============

@interface AuthorizationController ()

@property (nonatomic,assign) BOOL authWindow;

@end

@implementation AuthorizationController

- (void)viewDidAppear:(BOOL)animated{
    //[self pressInit];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Do any additional setup after loading the view.
    ///
    self.view.backgroundColor = [UIColor yellowColor];

    float WIDTH = self.view.frame.size.width;
    int commBtnH = 44;
    int commBtnW = 240;


    UIButton * accessCodeButton = [UIButton buttonWithType:UIButtonTypeSystem];
    [accessCodeButton setFrame:CGRectMake((WIDTH-commBtnW)/2, 124, commBtnW, commBtnH)];
    [accessCodeButton setBackgroundColor:[UIColor blueColor]];
    [accessCodeButton setTitle:@"预取号" forState:UIControlStateNormal];
    [accessCodeButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [accessCodeButton addTarget:self action:@selector(prepareGetAccessCode) forControlEvents:UIControlEventTouchUpInside];
    [accessCodeButton.titleLabel setFont:[UIFont systemFontOfSize:16]];
    accessCodeButton.layer.cornerRadius = 4;
    [self.view addSubview:accessCodeButton];

    UIButton * loginButton = [UIButton buttonWithType:UIButtonTypeSystem];
    [loginButton setFrame:CGRectMake((WIDTH-commBtnW)/2, 188, commBtnW, commBtnH)];
    [loginButton setBackgroundColor:[UIColor blueColor]];
    [loginButton setTitle:@"一键登录" forState:UIControlStateNormal];
    [loginButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [loginButton addTarget:self action:@selector(login) forControlEvents:UIControlEventTouchUpInside];
    [loginButton.titleLabel setFont:[UIFont systemFontOfSize:16]];
    loginButton.layer.cornerRadius = 4;
    [self.view addSubview:loginButton];

}

- (void)closeVC{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)openLogin{
    OneViewController * c = [[OneViewController alloc] init];
    [self.navigationController pushViewController:c animated:YES];
}

// 预取号处理
-(void)prepareGetAccessCode{
    [OclLogin.sharedInstance getAccessCodeFinishBlock:^(NSDictionary * _Nullable response) {
        NSLog(@"accessCode:%@",response);
    }];
}

-(void)login{
    OclModel *model = [[OclModel alloc] init];
    
    // 当前VC 必传 不传会提示调用失败
    model.authVC = self;
    
    // 1、授权页面是否需要弹出动画
    model.presentAnimated = YES;
    // 2、授权页面推出的动画效果
    model.presentType = PresentationDirectionBottom;
    // 3、授权界面背景图片
    //model.authPageBackgroundImage = [UIImage imageNamed:@"backgroundImage"];
    
#pragma mark 号码框设置
    // 1、按钮文字
    model.logBtnText = [[NSAttributedString alloc]initWithString:@"本机号码一键登录" attributes:@{NSForegroundColorAttributeName:[UIColor whiteColor]}];
    // 2、按钮高度
    model.logBtnHeight = 48.f;
    // 3、按钮Y轴偏移
    model.logBtnOffsetY = @200;
    // 4、按钮距离底部的高度
    // model.logBtnOffsetY_B = @100;
    // 5、按钮的左右边距
    model.logBtnOriginLR = @[@80,@80];
    // 6、按钮的3种状态
    // UIImage *norMal = [UIImage imageNamed:@"norMal"];
    // UIImage *invalied = [UIImage imageNamed:@"invalied"];
    // UIImage *highted = [UIImage imageNamed:@"highted"];
    // model.logBtnImgs = @[norMal,invalied,highted];
    
#pragma mark 号码样式
    // 1、手机号码富文本属性
    model.numberTextAttributes = @{NSForegroundColorAttributeName:UIColor.blackColor,NSFontAttributeName:[UIFont systemFontOfSize:32]};
    // 2、号码栏X偏移量
    model.numberOffsetX = @60;
    // 3、号码栏Y偏移量
    model.numberOffsetY = @100;
    // model.numberOffsetY_B = @20;
    
#pragma mark 隐私条款
    // 1、复选框未选中时图片
    // model.uncheckedImg = [UIImage imageNamed:@"checkOff"];
    // 2、复选框选中时图片
    // model.checkedImg = [UIImage imageNamed:@"checkOn"];
    // 3、复选框大小
    model.checkboxWH = @16;
    // 4、隐私条款（包括check框）的左右边距
    model.appPrivacyOriginLR = @[@20,@20];
    // 5、隐私的内容模板
    model.appPrivacyDemo = [[NSAttributedString alloc]initWithString:@"登录&&默认&&本界面并同意授权 *** 《使用协议》和《开发者公约》进行本机号码登录" attributes:@{NSFontAttributeName:[UIFont systemFontOfSize: 12],NSForegroundColorAttributeName:UIColor.blackColor}];
    // 6、隐私条款默认协议是否开启书名号
    model.privacySymbol = YES;
    // 7、隐私条款
    NSAttributedString *str1 = [[NSAttributedString alloc]initWithString:@"《使用协议》" attributes:@{NSLinkAttributeName:@"https://www.mysubmail.com"}];
    NSAttributedString *str2 = [[NSAttributedString alloc]initWithString:@"《开发者公约》" attributes:@{NSLinkAttributeName:@"https://www.mysubmail.com"}];
    model.appPrivacy = @[str1,str2];
    // 8、隐私条款名称颜色（协议）
    model.privacyColor = [UIColor blueColor];
    // 9、隐私条款偏移量
    // model.privacyOffsetY = [NSNumber numberWithFloat:(100/2)];
    // 10、隐私条款check框默认状态
    model.privacyState = YES;
    // 11、忽略隐私条款check框状态，登陆按钮一直可点击 默认:NO(不忽略)
    model.ignorePrivacyState = NO;
    // 12、隐私条款Y偏移量(注:此属性为与屏幕底部的距离)
    model.privacyOffsetY_B = @32;
    // 13、*隐私条款增加抖动效果 默认:NO
    model.privacyUncheckAnimation =YES;
    
#pragma mark 协议页面
    // 1、web协议界面导航返回图标(尺寸根据图片大小)
    model.webNavReturnImg = [UIImage imageNamed:@"title_back"];
    // 2、协议界面导航标题字体属性设置
    model.webNavTitleAttrs = @{NSForegroundColorAttributeName: [UIColor whiteColor], NSFontAttributeName: [UIFont systemFontOfSize:16]};
    // 3、web协议界面导航标题栏颜色
    model.webNavColor = [UIColor redColor];
    
    model.authViewBlock = ^(UIView *customView, CGRect numberFrame , CGRect loginBtnFrame,CGRect checkBoxFrame, CGRect privacyFrame) {
        UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake(UIScreen.mainScreen.bounds.size.width - 30,  10  + (44-30)/2, 20, 20)];
        [btn setImage:[UIImage imageNamed:@"TYRZResource.bundle/windowclose"] forState:UIControlStateNormal];
        [btn addTarget:self action:@selector(closeVC) forControlEvents:(UIControlEventTouchUpInside)];
        [customView addSubview:btn];
    };
    
#pragma mark 弹窗1
//    // 1、窗口模式开关
//    model.authWindow = YES;
//    // 2、窗口模式推出动画
//    model.modalTransitionStyle = UIModalTransitionStyleCoverVertical;
//    // 3、模态展示样式设置属性
//    model.modalPresentationStyle = UIModalPresentationOverFullScreen;
//    // 4、自定义窗口弧度
//    model.cornerRadius = 10;
//    // 5、自定义窗口弧度
//    model.cornerRadius = 5;
//    // 6、自定义窗口宽-缩放系数(屏幕宽乘以系数) 默认是0.8 其它比例自行配置
//    model.scaleW = 0.8;
//    // 7、自定义窗口高-缩放系数(屏幕高乘以系数) 默认是0.5 其它比例自行配置
//    model.scaleH = 0.5;
//
//    model.numberOffsetX = @0;
//    model.numberOffsetY = @160;
//
//    model.privacyOffsetY_B = @24;
//    model.logBtnOriginLR = @[@24,@24];
//    model.logBtnOffsetY_B = @80;
//    //在5、5s、5e下,需要改字体才能适配
//    BOOL isSmallScreen = UIScreen.mainScreen.bounds.size.height < 667.0f;
//    if (isSmallScreen) {
//        model.scaleW = 0.7;
//        model.privacyOffsetY_B = @5;
//    }
//
//    model.authViewBlock = ^(UIView *customView, CGRect numberFrame , CGRect loginBtnFrame,CGRect checkBoxFrame, CGRect privacyFrame) {
//        UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake(customView.bounds.size.width - 40,  16, 20, 20)];
//        [btn setImage:[UIImage imageNamed:@"TYRZResource.bundle/windowclose"] forState:UIControlStateNormal];
//        [btn addTarget:self action:@selector(closeVC) forControlEvents:(UIControlEventTouchUpInside)];
//        [customView addSubview:btn];
//    };
    
#pragma mark 弹窗2
    CGFloat overallScaleH = UIScreen.mainScreen.bounds.size.height/ 375.f;
    CGFloat overallScaleW = UIScreen.mainScreen.bounds.size.width/ 667.f;
    // 1、窗口模式开关
    model.authWindow = YES;
    // 2、弹窗背景透明度
    model.authWindowAlpha = 0.1;
    // 3、
    model.modalPresentationStyle = UIModalPresentationOverFullScreen;
    // 4、
    model.cornerRadius = 8;
    // 5、
    model.modalTransitionStyle = UIModalTransitionStyleFlipHorizontal;
    // 6、
    BOOL isSmallScreen = UIScreen.mainScreen.bounds.size.height < 375.f;
    model.scaleH = 0.7;
    model.scaleW = 0.8;
    model.numberOffsetX = @(-155 * overallScaleW);
    // 7、
    model.numberOffsetY_B = @((110 + (40 - 23.86)/2) * overallScaleH);
    // 8、
    model.privacyOffsetY_B = @(55 * overallScaleH);
    model.logBtnOffsetY = @300;
    model.logBtnOriginLR = @[@32,@32];
    // 9、
    model.authViewBlock = ^(UIView *customView, CGRect numberFrame , CGRect loginBtnFrame,CGRect checkBoxFrame, CGRect privacyFrame) {

        CGFloat subViewH = isSmallScreen ? 45 : 55;
        CGFloat imageH = isSmallScreen ? 30 : 40;

        UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake(customView.frame.size.width - 20 - 10, (imageH-20)/2 + 10, 20, 20)];
        [btn setImage:[UIImage imageNamed:@"TYRZResource.bundle/windowclose"] forState:UIControlStateNormal];
        [btn addTarget:self action:@selector(closeVC) forControlEvents:(UIControlEventTouchUpInside)];
        [customView addSubview:btn];

        UIView *line = [[UIView alloc]init];
        line.backgroundColor = [UIColor colorWithWhite:0 alpha:0.2];
        line.frame = CGRectMake(0, subViewH, customView.frame.size.width,1);
        [customView addSubview:line];

        UIView *thirdView = [[UIView alloc]init];
        thirdView.frame = CGRectMake(0, customView.frame.size.height - subViewH, customView.frame.size.width, subViewH);
        thirdView.backgroundColor = [UIColor colorWithRed:233/255.f green:234/255.f blue:254/255.f alpha:1];

        [customView addSubview:thirdView];

        //自定义------控件（仅供参考）
        UIButton *btnWeChat = [self setBtnWith:@"TYRZResource.bundle/微信1"];
        UIButton *btnQQ = [self setBtnWith:@"TYRZResource.bundle/qq1"];
        UIButton *btnWebo = [self setBtnWith:@"TYRZResource.bundle/微博1"];
        [btnWeChat setImageEdgeInsets:UIEdgeInsetsMake(5, 5, 5, 5)];
        [btnQQ setImageEdgeInsets:UIEdgeInsetsMake(5, 5, 5, 5)];
        [btnWebo setImageEdgeInsets:UIEdgeInsetsMake(5, 5, 5, 5)];

        UILabel *label = [[UILabel alloc]init];
        label.text = @"其它登录方式:";
        label.textColor = [UIColor grayColor];
        label.font = [UIFont systemFontOfSize:isSmallScreen ? 12 :15];
        label.textAlignment = NSTextAlignmentLeft;
        CGSize sizeLabel = [label.text sizeWithAttributes:@{NSForegroundColorAttributeName:label.textColor,NSFontAttributeName:label.font}];
        CGRect labelFrame =  label.frame;
        labelFrame.size = sizeLabel;
        label.frame = labelFrame;
        label.frame = CGRectMake(0, 0, thirdView.frame.size.width, label.frame.size.height);
        [thirdView addSubview:label];

        CGFloat btnW = subViewH - label.frame.size.height;
        CGFloat margin = 40;

        btnWeChat.frame = CGRectMake((thirdView.frame.size.width - 3 *btnW - 2 *margin)/2, CGRectGetMaxY(label.frame),btnW , btnW);
        btnQQ.frame = CGRectMake(CGRectGetMaxX(btnWeChat.frame) + margin, CGRectGetMaxY(label.frame), btnW, btnW);
        btnWebo.frame = CGRectMake(CGRectGetMaxX(btnQQ.frame) + margin, CGRectGetMaxY(label.frame), btnW, btnW);
        [thirdView addSubview:btnWeChat];
        [thirdView addSubview:btnQQ];
        [thirdView addSubview:btnWebo];

    };
     
    [OclLogin.sharedInstance getAccessToken:self WithModel:model complete:^(NSDictionary * _Nullable response) {
        NSNumber * code = response[@"code"];
        if([code intValue] == 0){
            [self getMobileWithAppid:@"10015" WithToken:response[@"accessToken"] completion:^(NSDictionary * _Nullable response) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    [self closeVC];
                    NSString * params = [[NSString alloc] initWithFormat:@"你的号码是：%@",response[@"mobile"]];
                    __block MBProgressHUD * hud = [[MBProgressHUD alloc] initWithView:self.view];
                    [self.view addSubview:hud];
                    hud.dimBackground = YES;
                    hud.labelText = params;
                    hud.mode = MBProgressHUDModeText;
                    [hud showAnimated:YES whileExecutingBlock:^{
                                        sleep(6);
                                    } completionBlock:^{
                                        [hud removeFromSuperview];
                                        hud = nil;
                                    }];
                });
                
            }];
        }
        
    }];
}



-(void)getMobileWithAppid:(NSString *) appid WithToken:(NSString *) token completion:(ResBlock)completion{
    NSString * timestamp = [self getCurrentTimer];
    NSURL * url_post = [NSURL URLWithString:@"https://tpa.mysubmail.com/ocl/getMobile_v2"];
    NSMutableURLRequest * request_post = [NSMutableURLRequest requestWithURL:url_post];
    request_post.HTTPMethod = @"POST";
    NSString * signature = @"730388900cc9624847b273d602262211";
    signature = [[NSString alloc] initWithFormat:@"%@%@%@",signature,timestamp,token];
    signature = [AuthorizationController getSHA256:signature];
    
    NSString * params = [[NSString alloc] initWithFormat:@"appid=%@&token=%@&os=IOS&timestamp=%@&signature=%@",appid,token,timestamp,signature];
    request_post.HTTPBody = [params dataUsingEncoding:NSUTF8StringEncoding];
    NSURLSession * session_post = [NSURLSession sharedSession];
    NSURLSessionDataTask *task_post = [session_post dataTaskWithRequest:request_post completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        if (error == NULL){
            NSError * err;
            NSDictionary * result = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:&err];
            if(!err){
                NSLog(@"服务器响应数据：%@",result);
                completion(result);
                
            }else{
                NSLog(@"服务器数据异常！%@",result);
            }
        }else{
            NSLog(@"服务器错误====%@",error);
        }
        
    }];
    [task_post resume];
}
-(NSString *) getCurrentTimer{
    NSDate* date = [NSDate dateWithTimeIntervalSinceNow:0];//获取当前时间0秒后的时间
    NSTimeInterval time=[date timeIntervalSince1970]*1000;// *1000 是精确到毫秒，不乘就是精确到秒
    NSString *timeString = [NSString stringWithFormat:@"%.0f", time];
    return timeString;
}


- (UIButton *)setBtnWith:(NSString *)imageName{
    UIButton *btn = [[UIButton alloc]init];
    [btn setImage:[UIImage imageNamed:imageName] forState:(UIControlStateNormal)];
    [btn setImageEdgeInsets:UIEdgeInsetsMake(20, 20, 20, 20)];

    return btn;
}


/**
 sha256加密
 
 @return 加密后的字符串
 */
+(NSString *) getSHA256:(NSString *) string {
    const char * str = [string cStringUsingEncoding:NSUTF8StringEncoding];
    NSData *keyData = [NSData dataWithBytes:str length:strlen(str)];
    uint8_t digest[CC_SHA256_DIGEST_LENGTH] = {0};
    CC_SHA256(keyData.bytes, (CC_LONG)keyData.length, digest);
    NSData *out = [NSData dataWithBytes:digest length:CC_SHA256_DIGEST_LENGTH];
    
    const unsigned *hashBytes = [out bytes];
    NSString * hash = [NSString stringWithFormat:@"%08x%08x%08x%08x%08x%08x%08x%08x",ntohl(hashBytes[0]),ntohl(hashBytes[1]),ntohl(hashBytes[2]),ntohl(hashBytes[3]),ntohl(hashBytes[4]),ntohl(hashBytes[5]),ntohl(hashBytes[6]),ntohl(hashBytes[7])];
    return hash;
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
