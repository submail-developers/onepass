//
//  OneViewController.m
//  sdk
//
//  Created by 段晓杰 on 2021/6/9.
//  Copyright © 2021 段晓杰. All rights reserved.
//

#import "OneViewController.h"
#import "TwoViewController.h"

@interface OneViewController ()


@end

@implementation OneViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor colorWithRed:255/255.f green:0/255.f blue:0/255.f alpha:0.5];
    
        float WIDTH = self.view.frame.size.width;
        int commBtnH = 44;
        int commBtnW = 240;
        UIButton * testButton = [UIButton buttonWithType:UIButtonTypeSystem];
        [testButton setFrame:CGRectMake((WIDTH-commBtnW)/2, 432, commBtnW, commBtnH)];
        [testButton setBackgroundColor:[UIColor blueColor]];
        [testButton setTitle:@"test" forState:UIControlStateNormal];
        [testButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [testButton addTarget:self action:@selector(openLogin) forControlEvents:UIControlEventTouchUpInside];
        [testButton.titleLabel setFont:[UIFont systemFontOfSize:16]];
        testButton.layer.cornerRadius = 4;
        [self.view addSubview:testButton];
}

- (void)openLogin{
    TwoViewController * c = [[TwoViewController alloc] init];
    [self.navigationController pushViewController:c animated:YES];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
